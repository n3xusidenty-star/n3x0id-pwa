Instrucciones básicas para probar la PWA
